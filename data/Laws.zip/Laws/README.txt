Files were accessed here:

48_states_1991_data.csv:
https://public.tableau.com/vizql/w/InteractiveMap_3/v/2015Dashboard/vud/sessions/425908A92881402294C284BCE99653D5-0:0/views/6096913504303594814_11168707477116641112?csv=true

Alaska_1991_data.csv:
https://public.tableau.com/vizql/w/InteractiveMap_3/v/2015Dashboard/vud/sessions/425908A92881402294C284BCE99653D5-0:0/views/6096913504303594814_13247172526359934450?csv=true

Hawaii_1991_data.csv:
https://public.tableau.com/vizql/w/InteractiveMap_3/v/2015Dashboard/viewData/sessions/425908A92881402294C284BCE99653D5-0:0/views/6096913504303594814_14695887912222215767?maxrows=200&viz=%7B%22worksheet%22:%22Hawaii%201991%22,%22dashboard%22:%222015%20Dashboard%22%7D

Date of access:
May 19, 2018

Notes:
The files were obtained through the website https://www.statefirearmlaws.org/law-data.html. The original files were not actually in CSV format; instead, they were in a sort of TSV format. I opened them in Microsoft Excel and converted them to CSV for easy reading into R.